
let students = JSON.parse(localStorage.getItem("students") || "[]");
const form = document.getElementById("addForm");
const tbody = document.getElementById("students");
const streamSelect = document.getElementById("stream");
const gradeSelect = document.getElementById("grade");
let editingIndex = null;

function populateStreams(grade) {
  streamSelect.innerHTML = '<option value="">Select Stream</option>';
  let options = grade <= 6 ? ["B", "Y", "G"] : ["N", "S", "E", "W"];
  options.forEach(opt => {
    streamSelect.innerHTML += `<option value="${opt}">${opt}</option>`;
  });
}

function getGrade(avg) {
  if (avg >= 80) return "EE";
  if (avg >= 60) return "ME";
  if (avg >= 40) return "AE";
  return "BE";
}

function updateTable() {
  tbody.innerHTML = "";
  students.forEach((s, i) => {
    tbody.innerHTML += `
      <tr>
        <td>${i + 1}</td>
        <td>${s.name}</td>
        <td>${s.grade}</td>
        <td>${s.stream}</td>
        <td>${s.english} (${getGrade(s.english)})</td>
        <td>${s.kiswahili} (${getGrade(s.kiswahili)})</td>
        <td>${s.math} (${getGrade(s.math)})</td>
        <td>${s.science} (${getGrade(s.science)})</td>
        <td>${s.agrinutrition} (${getGrade(s.agrinutrition)})</td>
        <td>${s.sst} (${getGrade(s.sst)})</td>
        <td>${s.creativearts} (${getGrade(s.creativearts)})</td>
        <td>${s.pretechnical ? s.pretechnical + " (" + getGrade(s.pretechnical) + ")" : "-"}</td>
        <td>${s.total}</td>
        <td>${s.average}</td>
        <td>${s.generalGrade}</td>
        <td>
          <button onclick="editStudent(${i})">Edit</button>
          <button onclick="deleteStudent(${i})">Delete</button>
        </td>
      </tr>
    `;
  });
  localStorage.setItem("students", JSON.stringify(students));
}

function deleteStudent(i) {
  if (confirm("Delete this student?")) {
    students.splice(i, 1);
    updateTable();
  }
}

function editStudent(i) {
  const s = students[i];
  document.getElementById("name").value = s.name;
  gradeSelect.value = s.grade;
  populateStreams(s.grade);
  streamSelect.value = s.stream;
  document.getElementById("english").value = s.english;
  document.getElementById("kiswahili").value = s.kiswahili;
  document.getElementById("math").value = s.math;
  document.getElementById("science").value = s.science;
  document.getElementById("agrinutrition").value = s.agrinutrition;
  document.getElementById("sst").value = s.sst;
  document.getElementById("creativearts").value = s.creativearts;
  document.getElementById("pretechnical").value = s.pretechnical;
  editingIndex = i;
}

form.onsubmit = (e) => {
  e.preventDefault();
  const student = {
    name: document.getElementById("name").value,
    grade: parseInt(gradeSelect.value),
    stream: streamSelect.value,
    english: parseInt(document.getElementById("english").value),
    kiswahili: parseInt(document.getElementById("kiswahili").value),
    math: parseInt(document.getElementById("math").value),
    science: parseInt(document.getElementById("science").value),
    agrinutrition: parseInt(document.getElementById("agrinutrition").value),
    sst: parseInt(document.getElementById("sst").value),
    creativearts: parseInt(document.getElementById("creativearts").value),
    pretechnical: parseInt(document.getElementById("pretechnical").value) || 0
  };

  let subjects = [
    student.english, student.kiswahili, student.math,
    student.science, student.agrinutrition,
    student.sst, student.creativearts
  ];
  if (student.grade >= 7) subjects.push(student.pretechnical);
  student.total = subjects.reduce((a, b) => a + b, 0);
  student.average = Math.round(student.total / subjects.length);
  student.generalGrade = getGrade(student.average);

  if (editingIndex !== null) {
    students[editingIndex] = student;
    editingIndex = null;
  } else {
    students.push(student);
  }

  form.reset();
  streamSelect.innerHTML = '<option value="">Select Stream</option>';
  updateTable();
};

gradeSelect.onchange = () => {
  const grade = parseInt(gradeSelect.value);
  populateStreams(grade);
};

updateTable();
